const apiKey = process.env.MAPSAPIKEY

module.exports = apiKey;
